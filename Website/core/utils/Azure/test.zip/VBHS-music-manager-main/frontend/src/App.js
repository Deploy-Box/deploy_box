import React from "react";
import "./App.css";
import Home from "./pages/Home";

function App() {
  return (
    <div style={{ padding: 10 }}>
      <Home />
    </div>
  );
}

export default App;
